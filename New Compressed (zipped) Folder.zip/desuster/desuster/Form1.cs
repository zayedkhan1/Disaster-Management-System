﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desuster
{
    public partial class Form1 : Form
    {
        int phone;

        public Form1()
        {
            InitializeComponent();
        }

    /*   public Form1(int i)
        {
            phone = i;
            InitializeComponent();
        } */

        private void button1_Click(object sender, EventArgs e)
        {
            string userPhone = textBox1.Text;
            string userPassword = textBox2.Text;

            if (string.IsNullOrWhiteSpace(userPhone) || string.IsNullOrWhiteSpace(userPassword))
            {
                MessageBox.Show("Please enter both Phone and Password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "Data Source=ALIF-PC\\SQLEXPRESS;Initial Catalog=\"Desuster management system\";Integrated Security=True;";
            string query = "SELECT Name FROM details WHERE Phone = @Phone AND Password COLLATE SQL_Latin1_General_CP1_CS_AS = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Phone", userPhone);
                    command.Parameters.AddWithValue("@Password", userPassword);

                    connection.Open();
                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        string userName = result.ToString();
                        MessageBox.Show("Login successful! Welcome, " + userName, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        
                        Form4 f4 = new Form4(userName);
                        this.Hide();
                        f4.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Phone or Password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2(phone);
            f2.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Confirm exit
            DialogResult result = MessageBox.Show(
                "Are you sure you want to exit the application?",
                "Confirm Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f4 = new Form3();
            f4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
          
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = !checkBox1.Checked;
        }
    }
}
