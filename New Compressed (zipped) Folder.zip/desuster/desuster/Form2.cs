﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace desuster
{
    public partial class Form2 : Form
    {
        int phone1;
        public Form2(int i)
        {
            phone1 = i;   
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=ALIF-PC\\SQLEXPRESS;Initial Catalog=\"Desuster management system\";Integrated Security=True;";

            string name = textBox1.Text.Trim();
            string password = textBox4.Text.Trim();
            string phone = textBox2.Text.Trim();
            string nid = textBox3.Text.Trim();
           // string dob= dateTimePicker1.Text.Trim();
            string address = richTextBox1.Text.Trim();
            string gender = radioButton1.Checked ? "Male" : "Female";
            if (radioButton1.Checked)
            {
                gender = radioButton1.Text;
            }
            else if (radioButton2.Checked)
            {
                gender = radioButton2.Text;
            }
            else if (radioButton3.Checked)
            {
                gender = radioButton3.Text;
            }

            if (string.IsNullOrWhiteSpace(nid) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(name) ||
                string.IsNullOrWhiteSpace(phone) || string.IsNullOrWhiteSpace(address))
            {
                MessageBox.Show("All fields must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string query = "INSERT INTO details (Name, Password, Phone, Nid, Gender, Date_of_Birth, Address) " +
               "VALUES (@Name, @Password, @Phone, @Nid, @Gender, @Date_of_Birth, @Address)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Phone", phone);
                    command.Parameters.AddWithValue("@Nid", nid);
                    command.Parameters.AddWithValue("@Gender", gender);

                    // 👇 মূল পরিবর্তন
                    DateTime dob = dateTimePicker1.Value;
                    command.Parameters.AddWithValue("@Date_of_Birth", dob);

                    command.Parameters.AddWithValue("@Address", address);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        Form1 f1 = new Form1();
                        f1.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to create the profile. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }





        }

        private void button2_Click(object sender, EventArgs e)
        {
           
                this.Hide();
                //Form1 f1 = new Form1();
               // f1.Show();

            
        }
        //Extra
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
