﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desuster
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private string loggedUser;

        // 👉 Constructor এর মাধ্যমে নাম রিসিভ করো
        public Form4(string userName)
        {
            InitializeComponent();
            loggedUser = userName;
        }
        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = "Welcome, " + loggedUser;
        }
    }
}
