﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace desuster
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            
        }

        private void show()
        {
            string cos = "Data Source=ALIF-PC\\SQLEXPRESS;Initial Catalog=\"Desuster management system\";Integrated Security=True;";
            SqlConnection conn = new SqlConnection(cos);
            conn.Open();
            string query = "select * from details";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //  textBox2
            //
            //MessageBox.Show(dataGridView1.Rows[e.RowIndex].ToString());
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Please select a row to update.");
                return;
            }

            string connectionString = "Data Source=ALIF-PC\\SQLEXPRESS;Initial Catalog=\"Desuster management system\";Integrated Security=True;";

            string oldPassword = dataGridView1.CurrentRow.Cells["Password"].Value.ToString();
            string newName = textBox2.Text;
            string newPassword = textBox3.Text;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = "UPDATE details SET Name=@Name, Password=@NewPassword WHERE Password=@OldPassword";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", newName);
                    cmd.Parameters.AddWithValue("@NewPassword", newPassword);
                    cmd.Parameters.AddWithValue("@OldPassword", oldPassword);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Selected row updated successfully!");
                    else
                        MessageBox.Show("No record found with this Password.");
                }
            }


            // GridView refresh
            show();
              //  clear();
            }
        

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            string connectionString = @"Data Source=ALIF-PC\SQLEXPRESS;Initial Catalog=Desuster management system;Integrated Security=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // CurrentRow থেকে Password নাও (যার ভিত্তিতে delete হবে)
                string passwordToDelete = dataGridView1.CurrentRow.Cells["Password"].Value.ToString();

                string query = "DELETE FROM details WHERE Password=@Password";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Password", passwordToDelete);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        MessageBox.Show("Selected row deleted successfully!");
                    else
                        MessageBox.Show("No record found with this Password.");
                }

                // Grid refresh
                show();
            }


            // GridView refresh
            show();
            }
        

        private void button5_Click(object sender, EventArgs e)
        {
            show();
            clear();


        }
        private void k1()
        {


        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //  textBox1.Clear();
          

        }
        private void txtsearch_Click(object sender, EventArgs e)
        {

        }
        public void clear()
        {
            //txtsearch.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

            // Placeholder reset
            textBox1.Text = "Please Enter Name";
            textBox1.ForeColor = Color.Black;
        }


       
        private void button2_Click(object sender, EventArgs e)
        {
            string cos = "Data Source=ALIF-PC\\SQLEXPRESS;Initial Catalog=\"Desuster management system\";Integrated Security=True;";
            SqlConnection conn = new SqlConnection(cos);
            conn.Open();
            string query = "select * from details where Name like '%" + textBox1.Text + "%'";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = dt;
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if(textBox1.Text== "Please Enter Name")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Please Enter Name";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f2 = new Form1();
            f2.Show();

        }
    }
}

